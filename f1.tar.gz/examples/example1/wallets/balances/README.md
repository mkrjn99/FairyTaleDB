This directory has CSV files that represents the ledger of the currency code, currently a string upto 5 letter long.
