We can define these block types for ChefBytes chain blocks:

1. init block
2. authorisation block
3. discount agreement block
4. money exchange block
5. non-money exchange block
