This directory contains all the abstract datatypes supported.
These are being defined in proto, as a way of me thanking Google for all the good engineering practices they have taught me, especially my first manager at Google: Kaushik Sridharan.
